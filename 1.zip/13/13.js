let palavra = prompt("Digite uma palavra:");
let ehPalindromo = true;

for (let i = 0; i < palavra.length / 2; i++) {
  if (palavra[i] !== palavra[palavra.length - 1 - i]) {
    ehPalindromo = false;
    break;
  }
}

console.log(ehPalindromo ? "É um palíndromo!" : "Não é um palíndromo.");