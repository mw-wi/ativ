let numero = parseInt(prompt("Digite um número:"));
let primo = true;

if (numero <= 1) primo = false;

for (let i = 2; i < numero; i++) {
  if (numero % i === 0) {
    primo = false;
    break;
  }
}

console.log(primo ? "É primo!" : "Não é primo!");