for (let index = 1; index <= 10; index++) {
   console.log(index);
}