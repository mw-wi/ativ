let numeros = [];
let numero;

while (true) {
  numero = prompt("Digite um número (0 para parar):");
  if (numero == "0") break;
  numeros.push(numero);
}

console.log("Números digitados: " + numeros.join(", "));