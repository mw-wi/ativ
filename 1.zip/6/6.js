let n = parseFloat(prompt("digite um numero positivo:"));
if (n>=0){
    let f = 1;
    for (let index = 1; index <= n ; index++) {
        f*=index;
    }
    console.log(f);
}else{
    console.log("digite um numero positivo:");
}