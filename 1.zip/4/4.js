let n = parseFloat(prompt("digite um numero:"));
for (let index = 1; index <= 10; index++) {
   if (n*index) {
    console.log(index);
   }
}