let resultado = 1;

for (let i = 0; i < 5; i++) {
  let numero = parseFloat(prompt("Digite um número:"));
  resultado *= numero;
}

console.log("Resultado da multiplicação: " + resultado);