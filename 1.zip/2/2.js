for (let index = 1; index <= 20; index++) {
    if (index%2==0){
        console.log(index);
    }
    
}