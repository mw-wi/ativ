let soma=0;
for (let index = 1; index <= 100; index++) {
   soma+=index;
   console.log(soma);
}